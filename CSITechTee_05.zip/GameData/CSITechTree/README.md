# CSI TechTree
 Cruesoe Space Industries Technology Tree


All credit to SpinkAkron and theOneGalen for the work on UnkerballedStart that I forked to make my own personal version.  Another credit to Heamec for the wonderful Icons I have used that were originally created for Kiwi Tech Tree.

After fiddling with TechTree's for such a long time I have taken the plunge and made my own. The Cruesoe Space Industries Tech Tree! (fanfare).

This is a Tree with UnKerballedStart as its core that I intend to feed and water and see what grows.
My intention is to combine the elements of previous tree's I have liked into a single place.

You'll see we have an UKS start, with IETP type branches later of Propulsion and Lifters, a set up in UKS and ITEPT I like.

There is more or less a dedicated line for:

	Propulsion (Space engines!)
	Lifters (Heavy lifting engines and boosters)
	Landing (heat shields, parachutes, lander cans)
	Probes (Unmanned Probe Cores)
	Manned Craft (Command Modules)
	Science (Science and Rover experiements)
	Logisitcs (Storage leading to Mining)
	Comms (All antennas in a few neat nodes)
	Habitation (Ground and Space Stations)
	Power (Batteries, solar, nuclear, cooling)

This post is merely to share a very new project, get some discussion going and keep myself motivated to 'finish' (can you ever finish a mod?)
Consider this very WIP.

Enjoy.

All credit to SpinkAkron and theOneGalen for the work on UnkerballedStart that I forked to make my own personal version.  Another credit to Heamec and KawaiiLucy for the wonderful Icons I have used that were originally created for Kiwi Tech Tree.

--
All credit to those that came before me, CTT, UKS, PBC, Kiwi, Tetrix, BET, IETP,  I salute you all.
--